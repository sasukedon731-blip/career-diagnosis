'use client'

import { useEffect, useMemo, useState } from 'react'
import { supabase } from '@/lib/supabase'

type JobProfile = {
  id: string
  job_name: string
  base_salary: number
  bonus: number
  raise_rate: number
}

type RegionCost = {
  id: string
  prefecture: string
  single_cost: number
  couple_cost: number
  family_cost: number
}

export default function Home() {
  const [jobs, setJobs] = useState<JobProfile[]>([])
  const [regions, setRegions] = useState<RegionCost[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [saveMessage, setSaveMessage] = useState('')

  const [name, setName] = useState('')
  const [age, setAge] = useState(25)
  const [desiredJob, setDesiredJob] = useState('')
  const [desiredIncome, setDesiredIncome] = useState(4000000)
  const [region, setRegion] = useState('')
  const [familyPlan, setFamilyPlan] = useState<'single' | 'couple' | 'family'>('single')

  useEffect(() => {
    const fetchMasterData = async () => {
      const [jobsRes, regionsRes] = await Promise.all([
        supabase.from('job_profiles').select('*').order('job_name'),
        supabase.from('region_costs').select('*').order('prefecture'),
      ])

      if (!jobsRes.error) setJobs(jobsRes.data ?? [])
      if (!regionsRes.error) setRegions(regionsRes.data ?? [])
      setLoading(false)
    }

    fetchMasterData()
  }, [])

  const result = useMemo(() => {
    const job = jobs.find((j) => j.job_name === desiredJob)
    const area = regions.find((r) => r.prefecture === region)

    if (!job || !area) return null

    const annualIncome = job.base_salary + job.bonus

    const annualCost =
      familyPlan === 'single'
        ? area.single_cost * 12
        : familyPlan === 'couple'
        ? area.couple_cost * 12
        : area.family_cost * 12

    const annualSaving = annualIncome - annualCost
    const incomeGap = annualIncome - desiredIncome

    let judgement = '少し厳しい'
    if (incomeGap >= 0 && annualSaving > 500000) judgement = '達成できそう'
    if (incomeGap < -1000000 || annualSaving < 0) judgement = '厳しい'

    let achievementRate = 70
    if (judgement === '達成できそう') achievementRate = 90
    if (judgement === '厳しい') achievementRate = 40

    return {
      annualIncome,
      annualCost,
      annualSaving,
      incomeGap,
      judgement,
      achievementRate,
    }
  }, [jobs, regions, desiredJob, desiredIncome, region, familyPlan])

  const handleSave = async () => {
    if (!result) {
      setSaveMessage('先に診断結果を出してください')
      return
    }

    setSaving(true)
    setSaveMessage('')

    try {
      const userRes = await supabase
        .from('users')
        .insert([
          {
            name: name || '匿名ユーザー',
            age,
            region,
            family_plan: familyPlan,
          },
        ])
        .select()
        .single()

      if (userRes.error || !userRes.data) {
        setSaveMessage(`ユーザー保存失敗: ${userRes.error?.message ?? '不明なエラー'}`)
        setSaving(false)
        return
      }

      const diagnosisRes = await supabase
        .from('diagnosis_results')
        .insert([
          {
            user_id: userRes.data.id,
            achievement_rate: result.achievementRate,
            economic_score: result.annualIncome,
            mental_score: 70,
            reality_score: result.annualSaving,
            recommended_job: desiredJob,
          },
        ])

      if (diagnosisRes.error) {
        setSaveMessage(`診断保存失敗: ${diagnosisRes.error.message}`)
        setSaving(false)
        return
      }

      setSaveMessage('保存成功！')
    } catch (error) {
      console.error(error)
      setSaveMessage('保存中にエラーが発生しました')
    }

    setSaving(false)
  }

  if (loading) {
    return <main style={{ padding: 24 }}>読み込み中...</main>
  }

  return (
    <main style={{ padding: 24, maxWidth: 720 }}>
      <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 24 }}>
        簡易キャリア診断
      </h1>

      <div style={{ display: 'grid', gap: 16 }}>
        <label>
          <div>名前</div>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            style={{ width: '100%', padding: 8 }}
          />
        </label>

        <label>
          <div>年齢</div>
          <input
            type="number"
            value={age}
            onChange={(e) => setAge(Number(e.target.value))}
            style={{ width: '100%', padding: 8 }}
          />
        </label>

        <label>
          <div>希望職種</div>
          <select
            value={desiredJob}
            onChange={(e) => setDesiredJob(e.target.value)}
            style={{ width: '100%', padding: 8 }}
          >
            <option value="">選択してください</option>
            {jobs.map((job) => (
              <option key={job.id} value={job.job_name}>
                {job.job_name}
              </option>
            ))}
          </select>
        </label>

        <label>
          <div>希望年収</div>
          <input
            type="number"
            value={desiredIncome}
            onChange={(e) => setDesiredIncome(Number(e.target.value))}
            style={{ width: '100%', padding: 8 }}
          />
        </label>

        <label>
          <div>地域</div>
          <select
            value={region}
            onChange={(e) => setRegion(e.target.value)}
            style={{ width: '100%', padding: 8 }}
          >
            <option value="">選択してください</option>
            {regions.map((r) => (
              <option key={r.id} value={r.prefecture}>
                {r.prefecture}
              </option>
            ))}
          </select>
        </label>

        <label>
          <div>ライフプラン</div>
          <select
            value={familyPlan}
            onChange={(e) => setFamilyPlan(e.target.value as 'single' | 'couple' | 'family')}
            style={{ width: '100%', padding: 8 }}
          >
            <option value="single">独身</option>
            <option value="couple">夫婦</option>
            <option value="family">家族あり</option>
          </select>
        </label>
      </div>

      {result && (
        <section
          style={{
            marginTop: 32,
            padding: 20,
            border: '1px solid #ddd',
            borderRadius: 12,
          }}
        >
          <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 12 }}>
            診断結果
          </h2>
          <p>想定年収: {result.annualIncome.toLocaleString()}円</p>
          <p>想定年間生活費: {result.annualCost.toLocaleString()}円</p>
          <p>想定年間貯蓄額: {result.annualSaving.toLocaleString()}円</p>
          <p>希望年収との差額: {result.incomeGap.toLocaleString()}円</p>
          <p>達成率目安: {result.achievementRate}%</p>
          <p style={{ fontWeight: 700, marginTop: 12 }}>
            判定: {result.judgement}
          </p>

          <button
            onClick={handleSave}
            disabled={saving}
            style={{
              marginTop: 16,
              padding: '10px 16px',
              borderRadius: 8,
              border: 'none',
              cursor: 'pointer',
            }}
          >
            {saving ? '保存中...' : '診断結果を保存'}
          </button>

          {saveMessage && (
            <p style={{ marginTop: 12 }}>
              {saveMessage}
            </p>
          )}
        </section>
      )}
    </main>
  )
}